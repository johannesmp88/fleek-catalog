import React from 'react'

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 flex items-center justify-center">
      <h1 className="text-4xl font-bold">🎉 Projeto configurado!</h1>
    </div>
  )
}
